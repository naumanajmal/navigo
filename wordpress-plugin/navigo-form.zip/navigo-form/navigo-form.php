<?php
/**
 * Plugin Name: Navigo Form Handler
 * Description: Handles form submissions from Navigo React website and provides shortcode for form display
 * Version: 1.0
 * Author: Your Name
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Create database table on plugin activation
function navigo_form_activate() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'navigo_form_submissions';
    
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        submission_date datetime DEFAULT CURRENT_TIMESTAMP,
        name varchar(100),
        phone varchar(50),
        mortgage_amount decimal(15,2),
        property_type varchar(50),
        residency_status varchar(50),
        age int,
        employment_type varchar(50),
        property_value decimal(15,2),
        purchase_timeline varchar(50),
        PRIMARY KEY  (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Add plugin options
    add_option('navigo_form_notification_email', get_option('admin_email'));
}
register_activation_hook(__FILE__, 'navigo_form_activate');

// Add admin menu
function navigo_form_admin_menu() {
    add_menu_page(
        'Navigo Form Settings',
        'Navigo Form',
        'manage_options',
        'navigo-form-settings',
        'navigo_form_settings_page',
        'dashicons-feedback'
    );
}
add_action('admin_menu', 'navigo_form_admin_menu');

// Admin settings page
function navigo_form_settings_page() {
    if (isset($_POST['navigo_form_notification_email'])) {
        update_option('navigo_form_notification_email', sanitize_email($_POST['navigo_form_notification_email']));
        echo '<div class="notice notice-success"><p>Settings saved successfully!</p></div>';
    }
    
    $notification_email = get_option('navigo_form_notification_email');
    ?>
    <div class="wrap">
        <h2>Navigo Form Settings</h2>
        <form method="post" action="">
            <table class="form-table">
                <tr>
                    <th scope="row">Notification Email</th>
                    <td>
                        <input type="email" name="navigo_form_notification_email" value="<?php echo esc_attr($notification_email); ?>" class="regular-text">
                        <p class="description">Email address where form submissions will be sent.</p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

// Register REST API endpoint
function navigo_form_register_rest_route() {
    register_rest_route('navigo/v1', '/submit-form', array(
        'methods' => 'POST',
        'callback' => 'navigo_form_handle_submission',
        'permission_callback' => '__return_true'
    ));
}
add_action('rest_api_init', 'navigo_form_register_rest_route');

// Handle form submission
function navigo_form_handle_submission($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'navigo_form_submissions';
    
    // Get parameters from request
    $params = $request->get_params();
    
    // Sanitize input data
    $data = array(
        'name' => sanitize_text_field($params['name']),
        'phone' => sanitize_text_field($params['phone']),
        'mortgage_amount' => floatval($params['mortgageAmount']),
        'property_type' => sanitize_text_field($params['propertyType']),
        'residency_status' => sanitize_text_field($params['residencyStatus']),
        'age' => intval($params['age']),
        'employment_type' => sanitize_text_field($params['employmentType']),
        'property_value' => floatval($params['propertyValue']),
        'purchase_timeline' => sanitize_text_field($params['purchaseTimeline'])
    );
    
    // Insert into database
    $result = $wpdb->insert($table_name, $data);
    
    if ($result === false) {
        return new WP_Error('db_error', 'Error saving form submission', array('status' => 500));
    }
    
    // Send email notification
    $to = get_option('navigo_form_notification_email');
    $subject = 'New Navigo Form Submission';
    
    $message = "New form submission received:\n\n";
    $message .= "Name: " . $data['name'] . "\n";
    $message .= "Phone: " . $data['phone'] . "\n";
    $message .= "Mortgage Amount: " . $data['mortgage_amount'] . "\n";
    $message .= "Property Type: " . $data['property_type'] . "\n";
    $message .= "Residency Status: " . $data['residency_status'] . "\n";
    $message .= "Age: " . $data['age'] . "\n";
    $message .= "Employment Type: " . $data['employment_type'] . "\n";
    $message .= "Property Value: " . $data['property_value'] . "\n";
    $message .= "Purchase Timeline: " . $data['purchase_timeline'] . "\n";
    
    wp_mail($to, $subject, $message);
    
    return new WP_REST_Response(array('message' => 'Form submitted successfully'), 200);
}

// Add shortcode for displaying submissions in admin
function navigo_form_submissions_shortcode() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'navigo_form_submissions';
    
    $submissions = $wpdb->get_results("SELECT * FROM $table_name ORDER BY submission_date DESC");
    
    ob_start();
    ?>
    <div class="navigo-form-submissions">
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Mortgage Amount</th>
                    <th>Property Type</th>
                    <th>Residency Status</th>
                    <th>Age</th>
                    <th>Employment Type</th>
                    <th>Property Value</th>
                    <th>Purchase Timeline</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($submissions as $submission): ?>
                <tr>
                    <td><?php echo esc_html($submission->submission_date); ?></td>
                    <td><?php echo esc_html($submission->name); ?></td>
                    <td><?php echo esc_html($submission->phone); ?></td>
                    <td><?php echo esc_html($submission->mortgage_amount); ?></td>
                    <td><?php echo esc_html($submission->property_type); ?></td>
                    <td><?php echo esc_html($submission->residency_status); ?></td>
                    <td><?php echo esc_html($submission->age); ?></td>
                    <td><?php echo esc_html($submission->employment_type); ?></td>
                    <td><?php echo esc_html($submission->property_value); ?></td>
                    <td><?php echo esc_html($submission->purchase_timeline); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('navigo_form_submissions', 'navigo_form_submissions_shortcode');
